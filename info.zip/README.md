# tag-and-release
Creates a tag (if not exists), release (if not exists), uploads assets (if not exists), and publishes to nuget.dev (if not exists) based on the version string specified
